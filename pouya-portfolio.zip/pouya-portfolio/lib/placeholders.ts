// All values below are intentionally empty placeholders.
// Fill them in yourself — nothing here was invented for you.

export type Project = {
  id: string;
  title: string;
  description: string;
  url: string;
  image: string;
  tags: string[];
};

export const projects: Project[] = [
  {
    id: "nova-self",
    title: "NoVA SeLF",
    description: "",
    url: "",
    image: "",
    tags: []
  },
  {
    id: "nova-panel",
    title: "NoVA PaNeL",
    description: "",
    url: "",
    image: "",
    tags: []
  },
  {
    id: "enlargeboobs",
    title: "EnlargeBoobs",
    description: "",
    url: "",
    image: "",
    tags: []
  }
];

export type SocialLink = {
  id: string;
  label: string;
  href: string;
  // icon key resolved in components/ui/SocialIcon.tsx
  icon: "telegram" | "github" | "instagram" | "discord" | "email" | "website";
};

export const socials: SocialLink[] = [
  { id: "telegram", label: "Telegram", href: "", icon: "telegram" },
  { id: "github", label: "GitHub", href: "", icon: "github" },
  { id: "instagram", label: "Instagram", href: "", icon: "instagram" },
  { id: "discord", label: "Discord", href: "", icon: "discord" },
  { id: "email", label: "Email", href: "", icon: "email" },
  { id: "website", label: "Website", href: "", icon: "website" }
];

// Shown once only, in the Footer.
export const location = "Iran, Rasht";

export type Locale = "en" | "fa";

export const translations = {
  en: {
    nav: {
      about: "About",
      work: "Work",
      connect: "Connect",
      contact: "Contact"
    },
    hero: {
      scroll: "Scroll"
    },
    about: {
      eyebrow: "About",
      reveal: "Reveal",
      hide: "Hide",
      placeholder: "// Write your introduction here"
    },
    projects: {
      eyebrow: "Selected Work",
      title: "Projects",
      view: "View project"
    },
    socials: {
      eyebrow: "Elsewhere",
      title: "Connect"
    },
    contact: {
      eyebrow: "Get in touch",
      title: "Contact",
      namePlaceholder: "Your name",
      emailPlaceholder: "Your email",
      messagePlaceholder: "Your message",
      send: "Send message"
    },
    footer: {
      rights: "All rights reserved."
    },
    langSwitch: "فا"
  },
  fa: {
    nav: {
      about: "درباره",
      work: "نمونه‌کار",
      connect: "شبکه‌ها",
      contact: "تماس"
    },
    hero: {
      scroll: "اسکرول"
    },
    about: {
      eyebrow: "درباره",
      reveal: "نمایش",
      hide: "پنهان",
      placeholder: "// متن معرفی خودت را اینجا بنویس"
    },
    projects: {
      eyebrow: "منتخب کارها",
      title: "پروژه‌ها",
      view: "مشاهده پروژه"
    },
    socials: {
      eyebrow: "دیگر جاها",
      title: "شبکه‌های اجتماعی"
    },
    contact: {
      eyebrow: "در ارتباط باشید",
      title: "تماس",
      namePlaceholder: "نام شما",
      emailPlaceholder: "ایمیل شما",
      messagePlaceholder: "پیام شما",
      send: "ارسال پیام"
    },
    footer: {
      rights: "تمامی حقوق محفوظ است."
    },
    langSwitch: "EN"
  }
} as const;

export type TranslationShape = typeof translations.en;
